"use client"

import type React from "react"

import { createContext, useContext, useState, type ReactNode, useRef, useEffect, useCallback } from "react"

// Atualize as interfaces para refletir a estrutura correta do MongoDB
export interface Music {
  _id: string
  titulo: string
  categoria: string
  caminho?: string // Campo correto retornado pela API
  arquivo?: string // Campo que usamos internamente
}

export interface Category {
  _id: string
  titulo: string
}

interface MusicContextType {
  currentMusic: Music | null
  setCurrentMusic: (music: Music) => void
  isPlaying: boolean
  setIsPlaying: (isPlaying: boolean) => void
  volume: number
  setVolume: (volume: number) => void
  audioRef: React.RefObject<HTMLAudioElement>
  selectedCategory: string
  setSelectedCategory: (categoryId: string) => void
  playMusic: (music: Music, continuePlayback?: boolean) => Promise<void>
  pauseMusic: () => void
}

const MusicContext = createContext<MusicContextType | undefined>(undefined)

export function MusicProvider({ children }: { children: ReactNode }) {
  const [currentMusic, setCurrentMusic] = useState<Music | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(0.7)
  const [selectedCategory, setSelectedCategory] = useState("")
  const [isPlayPending, setIsPlayPending] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  // Função centralizada para reproduzir música
  const playMusic = useCallback(
    async (music: Music, continuePlayback = false) => {
      // Evita múltiplas chamadas simultâneas
      if (isPlayPending) return

      setIsPlayPending(true)

      try {
        // Se for uma música diferente da atual, para a reprodução atual primeiro
        if (!continuePlayback && currentMusic && currentMusic._id !== music._id && isPlaying && audioRef.current) {
          audioRef.current.pause()
        }

        // Atualiza a música atual apenas se for uma nova música
        if (!continuePlayback || currentMusic?._id !== music._id) {
          setCurrentMusic(music)
        }

        // Aguarda um momento para garantir que o estado foi atualizado
        await new Promise((resolve) => setTimeout(resolve, 50))

        if (audioRef.current) {
          // Se for continuar a reprodução e for a mesma música, não redefine o src
          if (!(continuePlayback && currentMusic?._id === music._id)) {
            // Usa o campo arquivo ou caminho, dependendo de qual estiver disponível
            const audioPath = music.arquivo || music.caminho

            if (!audioPath) {
              throw new Error("Caminho de áudio não disponível")
            }

            // Certifique-se de que o src está definido corretamente
            const baseUrl = process.env.NEXT_PUBLIC_API_URL || ""

            // Corrige a construção da URL - remove /api/ se estiver presente no baseUrl
            const baseUrlWithoutApi = baseUrl.endsWith("/api") ? baseUrl.substring(0, baseUrl.length - 4) : baseUrl

            // Constrói a URL completa
            let fullPath
            if (audioPath.startsWith("http")) {
              fullPath = audioPath
            } else {
              // Remove barras duplicadas e constrói o caminho correto
              fullPath = `${baseUrlWithoutApi}/${audioPath.replace(/^\//, "")}`
            }

            console.log("URL do áudio construída:", fullPath)

            audioRef.current.src = fullPath
            audioRef.current.load()
          }

          console.log("Tentando reproduzir:", continuePlayback ? "Continuando de onde parou" : "Nova música")

          // Usa Promise com o método play()
          await audioRef.current.play()
          setIsPlaying(true)
        }
      } catch (error) {
        console.error("Erro ao reproduzir áudio:", error)
        setIsPlaying(false)
      } finally {
        setIsPlayPending(false)
      }
    },
    [currentMusic, isPlaying, isPlayPending],
  )

  // Função centralizada para pausar música
  const pauseMusic = useCallback(() => {
    if (audioRef.current && isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
    }
  }, [isPlaying])

  // Adicionar um efeito para lidar com eventos de áudio
  useEffect(() => {
    const audioElement = audioRef.current

    if (!audioElement) return

    const handleEnded = () => {
      setIsPlaying(false)
    }

    const handleError = (e: Event) => {
      console.error("Erro de áudio:", e)
      // Tenta obter mais informações sobre o erro
      if (audioElement.error) {
        console.error("Código de erro:", audioElement.error.code)
        console.error("Mensagem de erro:", audioElement.error.message)
      }
      setIsPlaying(false)
    }

    const handleCanPlay = () => {
      console.log("Áudio pronto para reprodução")
    }

    // Adicionar event listeners
    audioElement.addEventListener("ended", handleEnded)
    audioElement.addEventListener("error", handleError)
    audioElement.addEventListener("canplay", handleCanPlay)

    // Limpar event listeners
    return () => {
      audioElement.removeEventListener("ended", handleEnded)
      audioElement.removeEventListener("error", handleError)
      audioElement.removeEventListener("canplay", handleCanPlay)
    }
  }, [audioRef.current])

  // Efeito para atualizar o volume quando ele mudar
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  return (
    <MusicContext.Provider
      value={{
        currentMusic,
        setCurrentMusic,
        isPlaying,
        setIsPlaying,
        volume,
        setVolume,
        audioRef,
        selectedCategory,
        setSelectedCategory,
        playMusic,
        pauseMusic,
      }}
    >
      {children}
      <audio ref={audioRef} preload="auto" style={{ display: "none" }} />
    </MusicContext.Provider>
  )
}

export function useMusic() {
  const context = useContext(MusicContext)
  if (context === undefined) {
    throw new Error("useMusic must be used within a MusicProvider")
  }
  return context
}

