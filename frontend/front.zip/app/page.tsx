import Sidebar from "@/components/sidebar"
import MusicList from "@/components/music-list"
import Player from "@/components/player"

export default function Home() {
  return (
    <main className="flex flex-col md:flex-row min-h-screen">
      <Sidebar />
      <div className="flex flex-col flex-1 order-3 md:order-2">
        <MusicList />
      </div>
      <div className="order-2 md:order-3">
        <Player />
      </div>
    </main>
  )
}

