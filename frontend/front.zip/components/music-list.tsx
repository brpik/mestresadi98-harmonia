"use client"

import { useState, useEffect } from "react"
import { useMusic, type Music, type Category } from "@/context/music-context"
import { api } from "@/utils/api"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Play, Pause, ChevronLeft, ChevronRight, MusicIcon } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { abbreviateText } from "@/utils/string-utils"

export default function MusicList() {
  const [musics, setMusics] = useState<Music[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5

  const { currentMusic, isPlaying, audioRef, selectedCategory, setSelectedCategory, playMusic, pauseMusic } = useMusic()

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await api.get("/categorias")
        setCategories(response.data)
      } catch (error) {
        console.error("Erro ao buscar categorias:", error)
      }
    }

    fetchCategories()
  }, [])

  useEffect(() => {
    const fetchMusics = async () => {
      if (!selectedCategory) return

      setLoading(true)
      try {
        const response = await api.get(`/musicas/categoria/${selectedCategory}`)
        console.log("Músicas recebidas:", response.data)

        // Processa as músicas para usar o campo caminho em vez de arquivo
        const processedMusics = response.data.map((music: any) => {
          // Cria uma cópia segura do objeto música
          const musicCopy = { ...music }

          // Verifica se caminho existe e não é undefined
          if (musicCopy.caminho) {
            // Adiciona o campo arquivo para compatibilidade com o resto do código
            musicCopy.arquivo = musicCopy.caminho
            console.log(`Música encontrada: ${musicCopy.titulo}, caminho: ${musicCopy.caminho}`)
          } else {
            console.warn(`Música sem caminho: ${musicCopy.titulo || "Desconhecida"}`)
          }

          return musicCopy
        })

        setMusics(processedMusics)
        setCurrentPage(1)
      } catch (error) {
        console.error("Erro ao buscar músicas:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMusics()
  }, [selectedCategory])

  const handlePlay = async (music: Music) => {
    // Verifica se o arquivo ou caminho existe
    if (!music.arquivo && !music.caminho) {
      console.error("Tentativa de reproduzir música sem arquivo/caminho:", music)
      return
    }

    // Usa a função centralizada do contexto para reproduzir a música
    playMusic(music)
  }

  const handleSelectMusic = (music: Music) => {
    // Verifica se o arquivo ou caminho existe
    if (!music.arquivo && !music.caminho) {
      console.error("Tentativa de selecionar música sem arquivo/caminho:", music)
      return
    }

    // Se a música já estiver tocando, pausa. Caso contrário, toca a música
    if (currentMusic?._id === music._id && isPlaying) {
      pauseMusic()
    } else {
      playMusic(music)
    }
  }

  // Pagination logic
  const totalPages = Math.ceil(musics.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentMusics = musics.slice(startIndex, endIndex)

  return (
    <div className="flex-1 p-4 md:p-6">
      <div className="mb-4 md:mb-6">
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full md:w-[200px]">
            <SelectValue placeholder="Selecione uma categoria" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category._id} value={category._id}>
                {category.titulo}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {loading ? (
          Array(5)
            .fill(0)
            .map((_, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 border rounded-lg"
              >
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="flex-1 w-full sm:w-auto">
                  <Skeleton className="h-6 w-full sm:w-48 mb-2" />
                </div>
                <div className="flex flex-wrap gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                  <Skeleton className="h-10 w-full sm:w-28" />
                  <Skeleton className="h-10 w-full sm:w-28" />
                </div>
              </div>
            ))
        ) : currentMusics.length > 0 ? (
          currentMusics.map((music) => (
            <div
              key={music._id}
              className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors ${
                currentMusic?._id === music._id ? "bg-gray-100 border-primary" : ""
              }`}
              onClick={() => handleSelectMusic(music)}
            >
              <div className="h-12 w-12 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                {currentMusic?._id === music._id && isPlaying ? (
                  <Pause className="h-6 w-6 text-gray-600" />
                ) : (
                  <MusicIcon className="h-6 w-6 text-gray-600" />
                )}
              </div>
              <div className="flex-1 min-w-0 max-w-[40%] sm:max-w-[60%]">
                <h3 className="font-medium" title={music.titulo}>
                  {abbreviateText(music.titulo, 20)}
                </h3>
              </div>
              <div
                className="flex flex-nowrap gap-1 sm:gap-2 w-auto mt-2 sm:mt-0 ml-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <Button
                  variant="secondary"
                  onClick={(e) => {
                    e.stopPropagation()
                    handlePlay(music)
                  }}
                  disabled={!music.arquivo && !music.caminho}
                  title={!music.arquivo && !music.caminho ? "Arquivo de áudio não disponível" : ""}
                  className="w-auto min-w-0 h-8 px-2 text-xs"
                  size="sm"
                >
                  {currentMusic?._id === music._id && isPlaying ? (
                    <>
                      <span className="hidden sm:inline">Tocando...</span>
                      <span className="sm:hidden">▶️</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-3 w-3 mr-1 sm:mr-2" />
                      <span className="hidden xs:inline">Tocar</span>
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation()
                    pauseMusic()
                  }}
                  disabled={!(currentMusic?._id === music._id && isPlaying)}
                  className="w-auto min-w-0 h-8 px-2 text-xs"
                  size="sm"
                >
                  <Pause className="h-3 w-3 mr-1" />
                  <span>Pausar</span>
                </Button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">Nenhuma música encontrada nesta categoria</p>
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-4 mt-6">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span>
            Página {currentPage} de {totalPages}
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}

