"use client"

import { useEffect, useState } from "react"
import { useMusic } from "@/context/music-context"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, Music, Volume2 } from "lucide-react"
import { abbreviateText } from "@/utils/string-utils"

export default function Player() {
  const { currentMusic, isPlaying, volume, setVolume, audioRef, playMusic, pauseMusic } = useMusic()
  const [displayVolume, setDisplayVolume] = useState(Math.round(volume * 100))

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume, audioRef])

  useEffect(() => {
    // Atualiza o display de volume quando o volume muda
    setDisplayVolume(Math.round(volume * 100))
  }, [volume])

  const handlePlayPause = async () => {
    if (!currentMusic) return

    if (isPlaying) {
      pauseMusic()
    } else {
      // Continua a reprodução de onde parou
      playMusic(currentMusic, true)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
  }

  return (
    <div className="w-full md:w-64 bg-gray-100 p-4 md:p-6 flex flex-col border-t md:border-l md:border-t-0 md:min-h-screen">
      <div className="flex md:flex-col items-center md:justify-center gap-4">
        {currentMusic ? (
          <>
            <div className="w-16 h-16 md:w-32 md:h-32 lg:w-48 lg:h-48 bg-gray-300 md:mb-6 flex items-center justify-center rounded-lg flex-shrink-0">
              <Music className="h-8 w-8 md:h-16 md:w-16 lg:h-24 lg:w-24 text-gray-500" />
            </div>
            <div className="flex-1 md:flex-none md:text-center">
              <h3 className="text-sm md:text-lg font-medium md:mb-4">
                <span className="hidden md:inline">Tocando Agora:</span>
                <div className="font-bold mt-0 md:mt-1" title={currentMusic.titulo}>
                  {abbreviateText(currentMusic.titulo, 25)}
                </div>
              </h3>
              <div className="flex md:block space-y-0 md:space-y-3 gap-2 md:gap-0 mt-2 md:mt-0">
                <Button className="w-auto h-8 px-2" onClick={handlePlayPause} disabled={!currentMusic} size="sm">
                  {isPlaying ? (
                    <>
                      <Pause className="h-3 w-3 mr-1" />
                      <span>Pausar</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-3 w-3 mr-1" />
                      <span>Tocar</span>
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Controle de volume para todas as telas */}
            <div className="w-full mt-4 md:mt-8">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs md:text-sm font-medium">Volume</p>
                <span className="text-xs md:text-sm font-medium bg-primary text-primary-foreground px-2 py-1 rounded-md">
                  {displayVolume}%
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Volume2 className="h-3 w-3 md:h-4 md:w-4 text-gray-500" />
                <Slider
                  defaultValue={[volume]}
                  value={[volume]}
                  max={1}
                  step={0.01}
                  onValueChange={handleVolumeChange}
                  className="flex-1"
                />
              </div>
            </div>
          </>
        ) : (
          <div className="text-center w-full flex flex-col md:block items-center">
            <p className="text-gray-500 mb-2 md:mb-4">Nenhuma música selecionada</p>
            <div className="w-16 h-16 md:w-32 md:h-32 lg:w-48 lg:h-48 bg-gray-200 md:mx-auto md:mb-6 flex items-center justify-center rounded-lg">
              <Music className="h-8 w-8 md:h-16 md:w-16 lg:h-24 lg:w-24 text-gray-400" />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

