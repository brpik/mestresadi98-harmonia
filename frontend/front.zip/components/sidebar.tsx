"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useMusic } from "@/context/music-context"
import { api } from "@/utils/api"
import type { Category } from "@/context/music-context"
import { Skeleton } from "@/components/ui/skeleton"

export default function Sidebar() {
  const [logo, setLogo] = useState<string | null>(null)
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const { selectedCategory, setSelectedCategory } = useMusic()
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || ""

  useEffect(() => {
    const fetchLogo = async () => {
      try {
        // Corrigindo o endpoint para buscar o logo
        const response = await api.get("/config/logo")
        console.log("Logo response:", response.data)

        // Verifica se a resposta contém uma URL de logo
        if (response.data && response.data.logo) {
          // Corrige a construção da URL - remove /api/ se estiver presente no baseUrl
          const baseUrlWithoutApi = baseUrl.endsWith("/api") ? baseUrl.substring(0, baseUrl.length - 4) : baseUrl

          // Adiciona a baseURL se a URL não for absoluta
          const logoPath = response.data.logo
          let logoUrl

          if (typeof logoPath === "string") {
            if (logoPath.startsWith("http")) {
              logoUrl = logoPath
            } else {
              // Remove barras duplicadas e constrói o caminho correto
              logoUrl = `${baseUrlWithoutApi}/${logoPath.replace(/^\//, "")}`
            }

            console.log("URL da logo construída:", logoUrl)
            setLogo(logoUrl)
          }
        }
      } catch (error) {
        console.error("Erro ao buscar logo:", error)
        // Fallback logo será usado
      }
    }

    const fetchCategories = async () => {
      try {
        const response = await api.get("/categorias")
        setCategories(response.data)
        if (response.data.length > 0 && !selectedCategory) {
          setSelectedCategory(response.data[0]._id)
        }
      } catch (error) {
        console.error("Erro ao buscar categorias:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchLogo()
    fetchCategories()
  }, [setSelectedCategory, selectedCategory, baseUrl])

  return (
    <div className="w-full md:w-64 min-h-0 md:min-h-screen bg-gray-100 p-4 md:p-6 flex flex-col border-b md:border-r md:border-b-0">
      <div className="text-center mb-4 md:mb-8 flex flex-row md:flex-col items-center justify-start md:justify-center gap-4 md:gap-0">
        <div className="w-16 h-16 md:w-32 md:h-32 lg:w-40 lg:h-40 rounded-full overflow-hidden border-2 border-gray-300 flex-shrink-0">
          {loading ? (
            <Skeleton className="w-full h-full" />
          ) : (
            <Image
              src={logo || "/fallback-logo.png"}
              alt="Logo"
              width={160}
              height={160}
              className="object-cover"
              unoptimized
            />
          )}
        </div>
        <h1 className="text-xl md:text-2xl font-bold md:mt-4">Painel do Harmonia</h1>
      </div>

      <div className="flex-1">
        <h2 className="text-lg md:text-xl font-bold mb-2 md:mb-4">Categorias</h2>
        {loading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : (
          <div className="flex md:block overflow-x-auto md:overflow-visible pb-2 md:pb-0">
            <ul className="flex md:flex-col space-x-2 md:space-x-0 md:space-y-2">
              {categories.map((category) => (
                <li key={category._id} className="flex-shrink-0">
                  <button
                    onClick={() => setSelectedCategory(category._id)}
                    className={`whitespace-nowrap md:whitespace-normal text-left p-2 rounded ${
                      selectedCategory === category._id ? "bg-primary text-white" : "hover:bg-gray-200"
                    }`}
                  >
                    {category.titulo}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

